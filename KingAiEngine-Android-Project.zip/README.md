# King AI Engine for Android

"King AI Engine" is a complete, modern Android application built using **Kotlin**, **Jetpack Compose**, and **Google Gemini AI**.

---

## 🚀 How to Run in Android Studio (Step-by-Step)

### Prerequisites
1. **Android Studio**: Download [Android Studio Ladybug or Jellyfish](https://developer.android.com/studio) (2024.2+ recommended).
2. **Java Development Kit**: JDK 17 (bundled automatically with Android Studio).
3. **Android Device or Emulator**: Android 8.0 (API 26) or higher.

---

### Step 1: Download or Create the Project
- If you downloaded the ZIP from this dashboard:
  1. Extract `KingAiEngine.zip` to your desired folder (e.g. `~/AndroidStudioProjects/KingAiEngine`).
- If creating manually in Android Studio:
  1. Choose **New Project** -> **Empty Activity (Compose)**.
  2. Set Name to `King AI Engine`, Package Name to `com.kingai.engine`, Language to **Kotlin**, Build configuration to **Kotlin DSL (KTS)**.
  3. Replace the generated files with the source code provided in this repository.

---

### Step 2: Configure Your Gemini API Key
1. Open `app/src/main/java/com/kingai/engine/data/GeminiService.kt`.
2. Locate the line:
   ```kotlin
   private val apiKey = "YOUR_GEMINI_API_KEY_HERE"
   ```
3. Replace `YOUR_GEMINI_API_KEY_HERE` with your free Gemini API key from [Google AI Studio](https://aistudio.google.com/app/apikey).

*(Tip: In production, store keys in `local.properties` and inject via `BuildConfig.GEMINI_API_KEY` to keep your key private).*

---

### Step 3: Sync Gradle
1. Click the **Sync Project with Gradle Files** icon in Android Studio toolbar (elephant icon with blue arrow), or go to **File -> Sync Project with Gradle Files**.
2. Wait for dependencies (`generativeai:0.9.0`, Compose BOM) to download.

---

### Step 4: Run on Phone or Emulator
1. **On Emulator**:
   - Open **Device Manager** in Android Studio.
   - Click **Create Device** (e.g. Pixel 8, API 34).
   - Press the green **Play (Run 'app')** button.
2. **On Physical Android Phone**:
   - Enable **Developer Options** on your phone (Go to Settings -> About Phone -> tap "Build Number" 7 times).
   - Enable **USB Debugging**.
   - Plug phone into your computer via USB.
   - Select your device in Android Studio's device dropdown and click **Run**.

---

### Step 5: How to Build a Standalone APK
To install directly on any Android phone without a computer:
1. In Android Studio, go to **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
2. Android Studio will compile `app-debug.apk`.
3. Click the notification link **locate** to find the APK file in `app/build/outputs/apk/debug/`.
4. Transfer this APK to your phone and tap it to install!

---

## 📱 App Highlights
- **Jetpack Compose UI**: Clean, declarative, Material 3 design with Obsidian & Royal Gold aesthetic.
- **Instant Response Engine**: Powered by Google Generative AI (Gemini 3.8 / Flash) for quick Q&A.
- **Copy to Clipboard**: Quick 1-tap copy button on every AI answer.
- **Auto-Scroll & Responsive Layout**: Automatically adapts to keyboard appearance and screen rotations.
