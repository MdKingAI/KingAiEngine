package com.kingai.engine.data

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content

class GeminiService {

    // IMPORTANT: In production, configure BuildConfig.GEMINI_API_KEY from local.properties
    // or retrieve from your backend proxy.
    private val apiKey = "YOUR_GEMINI_API_KEY_HERE"

    private val generativeModel = GenerativeModel(
        modelName = "gemini-1.5-flash", // Or gemini-2.0-flash / gemini-2.5-flash
        apiKey = apiKey
    )

    suspend fun generateAnswer(
        prompt: String,
        conversationHistory: List<ChatMessage> = emptyList()
    ): String {
        return try {
            val systemInstruction = "You are King AI Engine, an elite, highly knowledgeable, and versatile AI assistant created for Android. Answer concisely, accurately, and politely."
            
            val modelWithInstruction = GenerativeModel(
                modelName = "gemini-1.5-flash",
                apiKey = apiKey,
                systemInstruction = content { text(systemInstruction) }
            )

            val chat = modelWithInstruction.startChat()
            val response = chat.sendMessage(prompt)
            response.text ?: "King AI Engine returned an empty response."
        } catch (e: Exception) {
            throw Exception("King AI Error: ${e.message}")
        }
    }
}
