package com.kingai.engine.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFFFDF73)
val GoldDark = Color(0xFF997A15)

val ObsidianBackground = Color(0xFF0D0E12)
val ObsidianSurface = Color(0xFF14151B)
val ObsidianCard = Color(0xFF1B1E29)

val UserBubble = Color(0xFF30364A)
val TextPrimary = Color(0xFFECEEF5)
val TextSecondary = Color(0xFFA0A3B1)
val TextMuted = Color(0xFF6B6E7D)
