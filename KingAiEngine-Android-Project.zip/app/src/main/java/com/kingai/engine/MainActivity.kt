package com.kingai.engine

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.kingai.engine.ui.KingAiScreen
import com.kingai.engine.ui.KingAiViewModel
import com.kingai.engine.ui.theme.KingAiTheme

class MainActivity : ComponentActivity() {
    private val viewModel: KingAiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KingAiTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    KingAiScreen(viewModel = viewModel)
                }
            }
        }
    }
}
