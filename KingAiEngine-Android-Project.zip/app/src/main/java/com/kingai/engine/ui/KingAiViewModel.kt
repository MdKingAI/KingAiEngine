package com.kingai.engine.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kingai.engine.data.ChatMessage
import com.kingai.engine.data.GeminiService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class KingAiUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class KingAiViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(KingAiUiState())
    val uiState: StateFlow<KingAiUiState> = _uiState.asStateFlow()

    private val geminiService = GeminiService()
    private var lastUserMessage: String? = null

    fun sendMessage(query: String) {
        if (query.isBlank() || _uiState.value.isLoading) return

        lastUserMessage = query

        val userMessage = ChatMessage(
            text = query,
            isUser = true,
            timestamp = System.currentTimeMillis()
        )

        // Optimistically add user message
        _uiState.update { current ->
            current.copy(
                messages = current.messages + userMessage,
                isLoading = true,
                errorMessage = null
            )
        }

        viewModelScope.launch {
            try {
                // Call Google Generative AI (Gemini 3.8 / 2.5 / Flash)
                val responseText = geminiService.generateAnswer(
                    prompt = query,
                    conversationHistory = _uiState.value.messages
                )

                val aiMessage = ChatMessage(
                    text = responseText,
                    isUser = false,
                    timestamp = System.currentTimeMillis()
                )

                _uiState.update { current ->
                    current.copy(
                        messages = current.messages + aiMessage,
                        isLoading = false,
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update { current ->
                    current.copy(
                        isLoading = false,
                        errorMessage = e.localizedMessage ?: "Failed to receive answer from King AI"
                    )
                }
            }
        }
    }

    fun retryLastMessage() {
        lastUserMessage?.let { sendMessage(it) }
    }

    fun clearConversation() {
        _uiState.update {
            KingAiUiState()
        }
    }
}
